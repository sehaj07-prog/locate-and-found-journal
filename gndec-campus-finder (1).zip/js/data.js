// All places live here. Add a new place by copying one line and changing the values.
// lat/lng: right-click a spot in Google Maps and copy the two numbers.
// keys: extra words people might type when searching (nicknames, related words).
window.TYPES = ["Department", "Library", "Events", "Sports", "Worship", "Other"];
window.PLACES = [
  {id:"g1", icon:"🏛️", name:"Main college block", building:"GNDEC", type:"Other", short:"Main block", lat:30.8604077, lng:75.860264, keys:"office admin principal entrance gate", how:"The main college area, reached from Gill Road. Most places here are a few minutes’ walk from it."},
  {id:"g2", icon:"💻", name:"CSE department", building:"Computer Science block", type:"Department", short:"CSE", lat:30.8598498, lng:75.8601488, keys:"computer science cs it labs coding", how:"Just south of the main block. Phone 0161 506 4547."},
  {id:"g3", icon:"📚", name:"Central library", building:"Central Library", type:"Library", short:"Library", lat:30.8582577, lng:75.8602691, keys:"books study read reading room", how:"Southern half of the campus, west of the auditorium. Open 8 am to 5 pm, closed Sunday."},
  {id:"g4", icon:"🎭", name:"Auditorium", building:"GNE Auditorium", type:"Events", short:"Auditorium", lat:30.8588799, lng:75.8607566, keys:"fest seminar function hall stage", how:"Central campus, east of the library. Seats about 1000."},
  {id:"g5", icon:"⚡", name:"Electrical department", building:"Electrical Engineering block", type:"Department", short:"Electrical", lat:30.8584871, lng:75.8611848, keys:"ee electrical power labs", how:"Just south-east of the auditorium."},
  {id:"g6", icon:"⚙️", name:"Production department", building:"Production Engineering block", type:"Department", short:"Production", lat:30.8588129, lng:75.8623597, keys:"mechanical workshop machines", how:"East side of the campus, towards the athletic ground."},
  {id:"g7", icon:"🏃", name:"Athletic ground", building:"GNDEC Athletic Sports Ground", type:"Sports", short:"Athletics", lat:30.8587449, lng:75.8639256, keys:"track running sports field", how:"Far east edge of the campus, past the Production department."},
  {id:"g8", icon:"⚽", name:"Football ground", building:"GNE Football Ground", type:"Sports", short:"Football", lat:30.8606828, lng:75.8613608, keys:"soccer playground field", how:"North-east of the main block. Open 24 hours."},
  {id:"g9", icon:"🙏", name:"Gurdwara Sahib", building:"Gurdwara Sahib, GNDEC", type:"Worship", short:"Gurdwara", lat:30.8620467, lng:75.8605582, keys:"prayer temple religion", how:"North end of the campus, beyond the football ground."},
  {id:"g10", icon:"🎓", name:"Polytechnic college", building:"Guru Nanak Dev Polytechnic", type:"Department", short:"Polytechnic", lat:30.8575298, lng:75.862262, keys:"diploma poly gnp", how:"South-east part of the campus. Phone 0161 249 0654."},
  {id:"g11", icon:"💡", name:"STEP GNDEC", building:"Science & Technology Entrepreneurs’ Park", type:"Other", short:"STEP", lat:30.8546818, lng:75.8625058, keys:"startup incubator courses training", how:"Southernmost point of the campus. Open 10 am to 7 pm, closed Sunday."}
];
