#pragma once
// Small helper functions used across the project.
#include <algorithm>
#include <sstream>
#include <string>
#include <vector>

inline std::string toLower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return std::tolower(c); });
    return s;
}
inline std::string trim(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n"), b = s.find_last_not_of(" \t\r\n");
    return a == std::string::npos ? "" : s.substr(a, b - a + 1);
}
inline std::vector<std::string> split(const std::string& s, char sep) {
    std::vector<std::string> out; std::string part; std::istringstream in(s);
    while (std::getline(in, part, sep)) out.push_back(part);
    if (!s.empty() && s.back() == sep) out.push_back("");
    return out;
}
