#pragma once
// CampusMap: owns every Place and the Journal. [OOP] Composition
#include <memory>
#include <string>
#include <vector>
#include "Journal.h"
#include "Place.h"

class CampusMap {
    std::vector<std::unique_ptr<Place>> places;   // unique_ptr: each place is freed automatically
    Journal journal;
    std::string customPath;

public:
    explicit CampusMap(const std::string& dataDir);

    size_t size() const { return places.size(); }
    void listAll() const;
    std::vector<size_t> search(const std::string& query) const;       // best match first
    std::vector<size_t> byCategory(const std::string& category) const;
    std::vector<std::string> categories() const;
    void showPlaces(const std::vector<size_t>& indexes) const;
    void showNearest(size_t index, size_t how_many = 3) const;
    void showProgress() const;
    void markFound(size_t index, const std::string& note);
    void unmark(size_t index);
    void addCustomPlace(const std::string& name, const std::string& building,
                        const std::string& how, const std::string& label);
};
