(function () {
  var KEY = "gndec-finder-v3";
  var SEED = window.PLACES, TYPES = window.TYPES;
  var places = load(), filter = "All", query = "", sel = null, pending = null;

  var $ = function (id) { return document.getElementById(id); };
  var qEl = $("q"), listEl = $("list"), chipsEl = $("chips");

  function load() {
    try {
      var saved = JSON.parse(localStorage.getItem(KEY));
      if (saved && typeof saved === "object") {
        // Built-in places always come from data.js; the device keeps only your journal and custom places.
        var prog = saved.progress || {}, custom = saved.custom || [];
        return SEED.map(function (p) { var s = prog[p.id] || {}; return Object.assign({}, p, { visited: !!s.visited, note: s.note || "" }); }).concat(custom);
      }
    } catch (e) {}
    return SEED.map(function (p) { return Object.assign({}, p, { visited: false, note: "" }); });
  }
  function save() {
    var progress = {}, custom = [];
    places.forEach(function (p) { if (p.custom) custom.push(p); else if (p.visited) progress[p.id] = { visited: true, note: p.note }; });
    try { localStorage.setItem(KEY, JSON.stringify({ progress: progress, custom: custom })); } catch (e) {}
  }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function words() { return query.toLowerCase().split(/\s+/).filter(Boolean); }

  // Higher score = better match. 0 = no match.
  function score(p) {
    var w = words(); if (!w.length) return 1;
    var name = p.name.toLowerCase(), rest = (p.building + " " + p.type + " " + (p.keys || "") + " " + (p.how || "")).toLowerCase(), total = 0;
    for (var i = 0; i < w.length; i++) {
      if (name.indexOf(w[i]) === 0) total += 4;
      else if (name.indexOf(w[i]) > -1) total += 3;
      else if (rest.indexOf(w[i]) > -1) total += 1;
      else return 0;
    }
    return total;
  }
  function matches(p) {
    if (filter === "Found" && !p.visited) return false;
    if (filter === "To find" && p.visited) return false;
    if (TYPES.indexOf(filter) > -1 && p.type !== filter) return false;
    return score(p) > 0;
  }
  function hl(text) {
    var out = esc(text), w = words();
    w.forEach(function (x) { var r = new RegExp("(" + x.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")(?![^<]*>)", "ig"); out = out.replace(r, "<mark>$1</mark>"); });
    return out;
  }

  // Map: converts real latitude/longitude into SVG x/y.
  var LAT0 = 30.8630, LNG0 = 75.8590, K = 0.62, PX = 111320 * Math.cos(30.86 * Math.PI / 180) * K, PY = 110574 * K;
  function drawMap() {
    var o = '<line class="fx" x1="20" y1="610" x2="82" y2="610"/><line class="fx" x1="20" y1="605" x2="20" y2="615"/><line class="fx" x1="82" y1="605" x2="82" y2="615"/><text class="fx-t" x="20" y="600">100 m</text>';
    o += '<text class="fx-t" x="350" y="30" text-anchor="middle">N</text><line class="fx" x1="350" y1="36" x2="350" y2="58"/>';
    places.forEach(function (p) {
      if (typeof p.lat !== "number") return;
      var x = Math.round((p.lng - LNG0) * PX) + 20, y = Math.round((LAT0 - p.lat) * PY) + 20;
      var cls = "pin" + (p.visited ? " visited" : "") + (matches(p) ? "" : " dim") + (p.id === sel ? " sel" : "");
      o += '<g class="' + cls + '" data-id="' + esc(p.id) + '" tabindex="0" role="button" aria-label="' + esc(p.name) + '"><circle cx="' + x + '" cy="' + y + '" r="' + (p.id === sel ? 12 : 9) + '"/><text x="' + x + '" y="' + (y + 24) + '">' + esc(p.short || p.name) + '</text></g>';
    });
    $("map").innerHTML = o;
  }

  function render() {
    chipsEl.innerHTML = ["All", "To find", "Found"].concat(TYPES).map(function (t) {
      return '<button class="chip" type="button" data-f="' + esc(t) + '" aria-pressed="' + (t === filter) + '">' + esc(t) + '</button>';
    }).join("");
    $("clear").hidden = !query;
    drawMap();
    var shown = places.filter(matches);
    if (query) shown.sort(function (a, b) { return score(b) - score(a); });
    $("count").textContent = shown.length + (shown.length === 1 ? " place" : " places");
    $("stats").textContent = places.filter(function (p) { return p.visited; }).length + " of " + places.length + " found";
    if (!shown.length) { listEl.innerHTML = '<div class="empty">Nothing matches “' + esc(query) + '”. Try a shorter word, or add this place below.</div>'; return; }
    listEl.innerHTML = shown.map(function (p) {
      return '<article class="place' + (p.visited ? " visited" : "") + (p.id === sel ? " sel" : "") + '" id="pl-' + esc(p.id) + '">' +
        '<div class="icon" aria-hidden="true">' + (p.visited ? "✅" : esc(p.icon || "📍")) + '</div><div>' +
        '<h2>' + hl(p.name) + '</h2><div class="where">' + hl(p.building) + '</div>' +
        (p.how ? '<p class="how">' + hl(p.how) + '</p>' : "") +
        '<div class="row"><span class="tag">' + esc(p.type) + '</span><span class="spacer"></span>' +
        (p.visited ? '<button class="btn found" data-a="undo" data-id="' + esc(p.id) + '">Found ✓</button>' : '<button class="btn primary" data-a="found" data-id="' + esc(p.id) + '">I found it</button>') +
        (p.custom ? '<button class="btn ghost" data-a="del" data-id="' + esc(p.id) + '" aria-label="Remove ' + esc(p.name) + '">Remove</button>' : "") +
        '</div>' + (p.visited && p.note ? '<div class="note"><small>Your journal note</small>' + esc(p.note) + '</div>' : "") + '</div></article>';
    }).join("");
  }

  // Events
  qEl.addEventListener("input", function () { query = qEl.value.trim(); sel = null; render(); });
  $("clear").addEventListener("click", function () { qEl.value = ""; query = ""; render(); qEl.focus(); });
  chipsEl.addEventListener("click", function (e) { var b = e.target.closest("[data-f]"); if (b) { filter = b.getAttribute("data-f"); render(); } });

  function pick(e) {
    var g = e.target.closest(".pin"); if (!g) return;
    if (e.type === "keydown" && e.key !== "Enter" && e.key !== " ") return;
    sel = g.getAttribute("data-id"); filter = "All"; query = ""; qEl.value = ""; render();
    var el = $("pl-" + sel); if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
  }
  $("map").addEventListener("click", pick);
  $("map").addEventListener("keydown", pick);

  var dlg = $("noteDlg");
  listEl.addEventListener("click", function (e) {
    var b = e.target.closest("[data-a]"); if (!b) return;
    var id = b.getAttribute("data-id"), a = b.getAttribute("data-a");
    var p = places.filter(function (x) { return x.id === id; })[0]; if (!p) return;
    if (a === "found") {
      pending = p; $("noteFor").textContent = p.name; $("noteText").value = "";
      if (dlg.showModal) dlg.showModal(); else { p.visited = true; save(); render(); }
    } else if (a === "undo") { p.visited = false; p.note = ""; save(); render(); }
    else if (a === "del") { places = places.filter(function (x) { return x.id !== id; }); save(); render(); }
  });
  $("noteForm").addEventListener("submit", function () {
    if (pending) { pending.visited = true; pending.note = $("noteText").value.trim(); pending = null; save(); render(); }
  });
  $("noteCancel").addEventListener("click", function () { pending = null; dlg.close(); });

  TYPES.forEach(function (t) { var o = document.createElement("option"); o.value = t; o.textContent = t; $("typeSel").appendChild(o); });
  $("addForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var f = new FormData(e.target);
    places.unshift({ id: "u" + Date.now(), custom: true, icon: "📍", name: String(f.get("name")).trim(), building: String(f.get("building")).trim(), type: String(f.get("type")), how: String(f.get("how") || "").trim(), keys: "", visited: false, note: "" });
    save(); e.target.reset(); $("addBox").open = false; filter = "All"; query = ""; qEl.value = ""; render();
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
  $("reset").addEventListener("click", function () {
    if (confirm("Clear your journal and any places you added?")) { try { localStorage.removeItem(KEY); } catch (e) {} places = load(); render(); }
  });

  render();
})();
