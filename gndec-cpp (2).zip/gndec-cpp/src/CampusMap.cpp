#include "CampusMap.h"
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <set>
#include "PlaceFactory.h"
#include "PlaceTypes.h"
#include "Utils.h"

static void readPlaces(const std::string& path, std::vector<std::unique_ptr<Place>>& out) {
    std::ifstream in(path);
    std::string line;
    while (std::getline(in, line))
        if (auto p = PlaceFactory::fromRecord(line)) out.push_back(std::move(p));
}

CampusMap::CampusMap(const std::string& dataDir)
    : journal(dataDir + "/journal.txt"), customPath(dataDir + "/custom.txt") {
    readPlaces(dataDir + "/places.txt", places);
    readPlaces(customPath, places);
    journal.load(places);
}

void CampusMap::showPlaces(const std::vector<size_t>& idx) const {
    if (idx.empty()) { std::cout << "No place matches that. Try a shorter word.\n"; return; }
    for (size_t i : idx) {
        std::cout << std::setw(2) << i + 1 << ". ";
        places[i]->show();                           // runs the right version for each type
        std::cout << "\n";
    }
}

void CampusMap::listAll() const {
    std::vector<size_t> all;
    for (size_t i = 0; i < places.size(); ++i) all.push_back(i);
    showPlaces(all);
}

std::vector<size_t> CampusMap::search(const std::string& q) const {
    std::vector<std::pair<int, size_t>> scored;
    for (size_t i = 0; i < places.size(); ++i)
        if (int s = places[i]->score(q)) scored.push_back({s, i});
    std::stable_sort(scored.begin(), scored.end(), [](auto& a, auto& b) { return a.first > b.first; });
    std::vector<size_t> out;
    for (auto& s : scored) out.push_back(s.second);
    return out;
}

std::vector<size_t> CampusMap::byCategory(const std::string& cat) const {
    std::vector<size_t> out;
    for (size_t i = 0; i < places.size(); ++i)
        if (toLower(places[i]->category()) == toLower(cat)) out.push_back(i);
    return out;
}

std::vector<std::string> CampusMap::categories() const {
    std::set<std::string> s;
    for (const auto& p : places) s.insert(p->category());
    return {s.begin(), s.end()};
}

void CampusMap::showNearest(size_t index, size_t howMany) const {
    if (!places[index]->hasLocation()) { std::cout << "This place has no map location.\n"; return; }
    std::vector<std::pair<double, size_t>> d;
    for (size_t i = 0; i < places.size(); ++i)
        if (i != index && places[i]->hasLocation()) d.push_back({*places[index] - *places[i], i});   // operator-
    std::sort(d.begin(), d.end());
    std::cout << "Closest to " << *places[index] << ":\n";                                            // operator<<
    for (size_t k = 0; k < howMany && k < d.size(); ++k)
        std::cout << "  " << std::fixed << std::setprecision(0) << d[k].first << " m  -  " << *places[d[k].second] << "\n";
}

void CampusMap::showProgress() const {
    int found = std::count_if(places.begin(), places.end(), [](const auto& p) { return p->isFound(); });
    std::cout << "You have found " << found << " of " << places.size() << " places.\n";
    std::map<std::string, std::pair<int, int>> byType;     // category -> (found, total)
    for (const auto& p : places) { byType[p->category()].second++; if (p->isFound()) byType[p->category()].first++; }
    for (const auto& kv : byType)
        std::cout << "  " << std::left << std::setw(12) << kv.first << kv.second.first << "/" << kv.second.second << "\n";
}

void CampusMap::markFound(size_t i, const std::string& note) { places[i]->markFound(note); journal.save(places); }
void CampusMap::unmark(size_t i) { places[i]->unmark(); journal.save(places); }

void CampusMap::addCustomPlace(const std::string& name, const std::string& building,
                               const std::string& how, const std::string& label) {
    auto clean = [](std::string s) { std::replace(s.begin(), s.end(), '|', '/'); return trim(s); };
    auto p = std::make_unique<GeneralPlace>(clean(name), clean(building), 0.0, 0.0, clean(how), "", clean(label).empty() ? "Other" : clean(label));
    std::ofstream out(customPath, std::ios::app);          // append so older custom places stay
    out << p->toRecord() << "\n";
    places.push_back(std::move(p));
}
