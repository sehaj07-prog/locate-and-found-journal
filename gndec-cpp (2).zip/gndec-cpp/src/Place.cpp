#include "Place.h"
#include <cmath>
#include <iomanip>
#include <sstream>
#include "Utils.h"

Place::Place(std::string n, std::string b, double la, double lo, std::string h, std::string k)
    : name(std::move(n)), building(std::move(b)), how(std::move(h)), keywords(std::move(k)), lat(la), lng(lo) {}

std::string Place::details() const { return ""; }

void Place::show() const {
    std::cout << (found ? "[x] " : "[ ] ") << name << "  (" << category() << ")\n"
              << "      " << building << "\n";
    if (!how.empty()) std::cout << "      " << how << "\n";
    std::string d = details();                       // polymorphic call
    if (!d.empty()) std::cout << "      " << d << "\n";
    if (found && !note.empty()) std::cout << "      Journal: " << note << "\n";
}

std::string Place::toRecord() const {
    std::ostringstream os;
    os << std::setprecision(10) << typeTag() << "|" << name << "|" << building << "|" << lat << "|" << lng
       << "|" << how << "|" << keywords << "|" << extra();
    return os.str();
}

// Every word you type must appear somewhere. Matches in the name count more.
int Place::score(const std::string& query) const {
    std::string n = toLower(name);
    std::string rest = toLower(building + " " + category() + " " + keywords + " " + how);
    std::istringstream words(toLower(query));
    std::string w; int total = 0;
    while (words >> w) {
        size_t pos = n.find(w);
        if (pos == 0) total += 4;
        else if (pos != std::string::npos) total += 3;
        else if (rest.find(w) != std::string::npos) total += 1;
        else return 0;
    }
    return total == 0 ? 1 : total;                   // empty query matches everything
}

// Distance in metres using the haversine formula.
double Place::operator-(const Place& o) const {
    const double R = 6371000.0, rad = 3.14159265358979323846 / 180.0;
    double dLa = (o.lat - lat) * rad, dLo = (o.lng - lng) * rad;
    double a = std::sin(dLa / 2) * std::sin(dLa / 2) +
               std::cos(lat * rad) * std::cos(o.lat * rad) * std::sin(dLo / 2) * std::sin(dLo / 2);
    return 2 * R * std::asin(std::sqrt(a));
}

std::ostream& operator<<(std::ostream& os, const Place& p) {
    return os << p.name << " (" << p.category() << ")";
}
