#pragma once
// Builds the right kind of Place from one line of a data file (the Factory pattern).
#include <memory>
#include <string>
#include "Place.h"

class PlaceFactory {
public:
    // Returns nullptr if the line is blank, a comment, or badly formed.
    static std::unique_ptr<Place> fromRecord(const std::string& line);
};
