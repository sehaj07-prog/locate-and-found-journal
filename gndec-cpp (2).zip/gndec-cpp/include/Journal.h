#pragma once
// Journal: saves which places you found, plus your notes, to a text file.
#include <memory>
#include <string>
#include <vector>
#include "Place.h"

class Journal {
    std::string path;
public:
    explicit Journal(std::string path) : path(std::move(path)) {}
    void save(const std::vector<std::unique_ptr<Place>>& places) const;
    void load(std::vector<std::unique_ptr<Place>>& places) const;
};
