#pragma once
// Place: the abstract base class for everything on the campus map.
//
// [OOP] Abstraction   - pure virtual functions below force every kind of place to describe itself
// [OOP] Encapsulation - data is protected; outside code uses getters and markFound()/unmark()
// [OOP] Polymorphism  - show() is virtual and calls the derived class's details()
#include <iostream>
#include <string>

class Place {
protected:
    std::string name, building, how, keywords;
    double lat, lng;
    bool found = false;
    std::string note;

public:
    Place(std::string name, std::string building, double lat, double lng,
          std::string how, std::string keywords);
    virtual ~Place() = default;                 // virtual destructor: safe delete through Place*

    // Every derived class must provide these three.
    virtual std::string category() const = 0;   // shown to the user, e.g. "Library"
    virtual std::string typeTag() const = 0;    // used in data files, e.g. "library"
    virtual std::string extra() const = 0;      // the one extra field stored in the data file

    virtual std::string details() const;        // optional extra line for show()
    virtual void show() const;                  // prints the place
    std::string toRecord() const;               // one line of the data file

    // Getters and controlled changes (Encapsulation)
    const std::string& getName() const { return name; }
    const std::string& getNote() const { return note; }
    bool isFound() const { return found; }
    bool hasLocation() const { return lat != 0.0 || lng != 0.0; }
    void markFound(const std::string& n) { found = true; note = n; }
    void unmark() { found = false; note.clear(); }

    int score(const std::string& query) const;  // 0 = no match, higher = better match

    // [OOP] Operator overloading
    double operator-(const Place& other) const; // distance in metres
    friend std::ostream& operator<<(std::ostream& os, const Place& p);
};
