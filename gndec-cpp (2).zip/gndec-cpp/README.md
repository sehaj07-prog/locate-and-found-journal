# GNDEC Campus Finder (C++)

A menu-driven C++17 program for finding places on the Guru Nanak Dev Engineering College campus.
Search places, browse by type, log the ones you find with notes, see the closest places, and add missing ones.

## Folder structure
```
gndec-cpp/
├── include/
│   ├── Utils.h          small helpers (toLower, trim, split)
│   ├── Place.h          abstract base class
│   ├── PlaceTypes.h     Department, Library, SportsGround, Hall, GeneralPlace
│   ├── PlaceFactory.h   builds a Place from a data-file line
│   ├── Journal.h        saves found places and notes
│   └── CampusMap.h      owns all places, search, nearest, progress
├── src/
│   ├── main.cpp         the menu
│   ├── Place.cpp  PlaceFactory.cpp  Journal.cpp  CampusMap.cpp
├── data/
│   └── places.txt       the campus places (edit this to add or fix places)
├── Makefile
├── CMakeLists.txt
└── README.md
```
`data/journal.txt` and `data/custom.txt` are created automatically when you save a journal note or add a place.

## Build and run
Needs a C++17 compiler (g++ 7 or newer, clang, or MSVC).

    make          # builds ./campus_finder
    ./campus_finder

Without make:  `g++ -std=c++17 -Iinclude src/*.cpp -o campus_finder`
With CMake:    `cmake -S . -B build && cmake --build build`

Run it from this folder so it can find `data/`. To use another data folder: `./campus_finder path/to/data`.

## OOP concepts and where to find them
| Concept | Where |
|---|---|
| Abstraction | `Place.h`: pure virtual `category()`, `typeTag()`, `extra()` |
| Encapsulation | `Place.h`: protected data, getters, `markFound()` / `unmark()` |
| Inheritance | `PlaceTypes.h`: five classes derive from `Place` |
| Polymorphism | `Place::show()` calls the virtual `details()`; `CampusMap` calls `show()` through `Place` pointers |
| Operator overloading | `Place::operator-` (distance in metres), `operator<<` |
| Factory pattern | `PlaceFactory::fromRecord()` picks the right class from the file |
| Composition | `CampusMap` owns the places (`unique_ptr`) and a `Journal` |
| File handling | `Journal.cpp`, `CampusMap.cpp`, `PlaceFactory.cpp` |
| STL | `vector`, `map`, `set`, `sort`, `unique_ptr` |

## Add a place by editing the data file
Copy a line in `data/places.txt`. Format: `type|name|building|latitude|longitude|how to get there|search words|extra`.
Types: `department` (extra = phone), `library` (extra = hours), `sports` (extra = 1 if open 24 hours, else 0), `hall` (extra = seats), `general` (extra = type label, for example Worship).
Get latitude and longitude by right-clicking the spot in Google Maps. Hostels, canteen and swimming pool are not included yet because I did not have reliable coordinates.
