#include "Journal.h"
#include <fstream>
#include "Utils.h"

void Journal::save(const std::vector<std::unique_ptr<Place>>& places) const {
    std::ofstream out(path);
    for (const auto& p : places)
        if (p->isFound()) out << p->getName() << "|" << p->getNote() << "\n";
}

void Journal::load(std::vector<std::unique_ptr<Place>>& places) const {
    std::ifstream in(path);
    std::string line;
    while (std::getline(in, line)) {
        size_t bar = line.find('|');
        if (bar == std::string::npos) continue;
        std::string nm = line.substr(0, bar), nt = line.substr(bar + 1);
        for (auto& p : places) if (p->getName() == nm) p->markFound(nt);
    }
}
