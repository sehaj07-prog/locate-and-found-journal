#include "PlaceFactory.h"
#include "PlaceTypes.h"
#include "Utils.h"

std::unique_ptr<Place> PlaceFactory::fromRecord(const std::string& line) {
    std::string l = trim(line);
    if (l.empty() || l[0] == '#') return nullptr;
    auto f = split(l, '|');
    if (f.size() < 8) return nullptr;
    try {
        const std::string &type = f[0], &name = f[1], &building = f[2], &how = f[5], &keys = f[6], &extra = f[7];
        double lat = std::stod(f[3]), lng = std::stod(f[4]);
        if (type == "department") return std::make_unique<Department>(name, building, lat, lng, how, keys, extra);
        if (type == "library")    return std::make_unique<Library>(name, building, lat, lng, how, keys, extra);
        if (type == "sports")     return std::make_unique<SportsGround>(name, building, lat, lng, how, keys, extra == "1");
        if (type == "hall")       return std::make_unique<Hall>(name, building, lat, lng, how, keys, std::stoi(extra));
        return std::make_unique<GeneralPlace>(name, building, lat, lng, how, keys, extra.empty() ? "Other" : extra);
    } catch (...) { return nullptr; }
}
