# GNDEC Campus Finder

A mobile-friendly web app that helps students find places on the Guru Nanak Dev Engineering College campus (Gill Park, Ludhiana).
No installation, build step or account needed.

## Folder structure
```
gndec-campus-finder/
├── index.html      page layout (search box, map, list, forms)
├── manifest.webmanifest  app name, colours and icons (makes it installable)
├── sw.js           lets the app open without internet
├── icons/          app icons
├── css/
│   └── style.css   colours, fonts, layout, dark mode
├── js/
│   ├── data.js     the list of campus places (edit this to add or fix places)
│   └── app.js      search, map drawing, journal, saving
└── README.md
```

## Run it on your computer
1. Unzip the folder.
2. Double-click `index.html`. It opens in your browser and works.

## Put it online for free (so students can use it on phones)
- **Netlify Drop**: go to app.netlify.com/drop and drag the whole folder in. You get a link right away.
- **GitHub Pages**: upload the folder to a GitHub repository, then Settings → Pages → deploy from the main branch.

## Install it as an app on a phone
1. Put the folder online first (Netlify Drop above). Installing needs an https link.
2. **Android (Chrome):** open the link, tap the ⋮ menu, then **Install app**.
3. **iPhone (Safari):** open the link, tap Share, then **Add to Home Screen**.
The app then has its own icon and opens full screen, even offline.

## Make an Android APK (to share as a file or put on Play Store)
Go to pwabuilder.com, paste your Netlify link, and choose **Android**. It gives you an APK to download.

## Add or correct a place
Open `js/data.js` and copy one line. Change `name`, `building`, `type`, `lat`, `lng`, `keys` and `how`.
To get `lat` and `lng`: in Google Maps, right-click the spot and click the two numbers shown at the top of the menu.
`keys` are extra search words (for example "prayer" finds the Gurdwara).

## Notes
- A student’s journal (places found and notes) is saved in their own browser only, not shared.
- The map is a schematic: pins are placed from real coordinates, but roads and building outlines are not drawn.
- Not yet added: hostels, canteen and swimming pool. Add them to `data.js` once you have their coordinates.
