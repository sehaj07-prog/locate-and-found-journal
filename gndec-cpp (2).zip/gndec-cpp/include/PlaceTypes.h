#pragma once
// The different kinds of place. Each one inherits from Place. [OOP] Inheritance
#include "Place.h"

class Department : public Place {
    std::string phone;
public:
    Department(std::string n, std::string b, double la, double lo, std::string h, std::string k, std::string phone)
        : Place(n, b, la, lo, h, k), phone(std::move(phone)) {}
    std::string category() const override { return "Department"; }
    std::string typeTag() const override { return "department"; }
    std::string extra() const override { return phone; }
    std::string details() const override { return phone.empty() ? "" : "Phone: " + phone; }
};

class Library : public Place {
    std::string hours;
public:
    Library(std::string n, std::string b, double la, double lo, std::string h, std::string k, std::string hours)
        : Place(n, b, la, lo, h, k), hours(std::move(hours)) {}
    std::string category() const override { return "Library"; }
    std::string typeTag() const override { return "library"; }
    std::string extra() const override { return hours; }
    std::string details() const override { return "Open: " + hours; }
};

class SportsGround : public Place {
    bool open24h;
public:
    SportsGround(std::string n, std::string b, double la, double lo, std::string h, std::string k, bool open24h)
        : Place(n, b, la, lo, h, k), open24h(open24h) {}
    std::string category() const override { return "Sports"; }
    std::string typeTag() const override { return "sports"; }
    std::string extra() const override { return open24h ? "1" : "0"; }
    std::string details() const override { return open24h ? "Open 24 hours" : ""; }
};

class Hall : public Place {
    int capacity;
public:
    Hall(std::string n, std::string b, double la, double lo, std::string h, std::string k, int capacity)
        : Place(n, b, la, lo, h, k), capacity(capacity) {}
    std::string category() const override { return "Events"; }
    std::string typeTag() const override { return "hall"; }
    std::string extra() const override { return std::to_string(capacity); }
    std::string details() const override { return "Seats about " + std::to_string(capacity); }
};

// Anything else (worship, offices, places you add yourself). The label is its category.
class GeneralPlace : public Place {
    std::string label;
public:
    GeneralPlace(std::string n, std::string b, double la, double lo, std::string h, std::string k, std::string label)
        : Place(n, b, la, lo, h, k), label(std::move(label)) {}
    std::string category() const override { return label; }
    std::string typeTag() const override { return "general"; }
    std::string extra() const override { return label; }
};
