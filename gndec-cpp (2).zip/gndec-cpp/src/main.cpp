// GNDEC Campus Finder - menu program. Run it from the project folder (so it can find data/).
#include <iostream>
#include <string>
#include "CampusMap.h"
#include "Utils.h"

static std::string ask(const std::string& prompt) {
    std::cout << prompt;
    std::string s; std::getline(std::cin, s);
    return trim(s);
}
// Returns a 0-based index, or size() if the input was not a valid place number.
static size_t askPlace(const CampusMap& campus) {
    std::string s = ask("Place number: ");
    try { size_t n = std::stoul(s); if (n >= 1 && n <= campus.size()) return n - 1; } catch (...) {}
    std::cout << "That is not a valid place number.\n";
    return campus.size();
}

int main(int argc, char* argv[]) {
    std::string dataDir = argc > 1 ? argv[1] : "data";
    CampusMap campus(dataDir);
    if (campus.size() == 0) { std::cout << "Could not read " << dataDir << "/places.txt. Run from the project folder.\n"; return 1; }

    std::cout << "=== GNDEC Campus Finder ===\n";
    while (std::cin) {
        std::cout << "\n1. Search\n2. Show all places\n3. Browse by type\n4. Mark a place as found\n"
                     "5. Unmark a place\n6. Closest places to...\n7. Add a missing place\n8. My progress\n0. Exit\n";
        std::string c = ask("Choose: ");
        if (c == "0") break;
        else if (c == "1") campus.showPlaces(campus.search(ask("Search: ")));
        else if (c == "2") campus.listAll();
        else if (c == "3") {
            std::cout << "Types:";
            for (auto& t : campus.categories()) std::cout << "  " << t;
            std::cout << "\n";
            campus.showPlaces(campus.byCategory(ask("Type: ")));
        }
        else if (c == "4") { size_t i = askPlace(campus); if (i < campus.size()) { campus.markFound(i, ask("Journal note (optional): ")); std::cout << "Saved.\n"; } }
        else if (c == "5") { size_t i = askPlace(campus); if (i < campus.size()) { campus.unmark(i); std::cout << "Unmarked.\n"; } }
        else if (c == "6") { size_t i = askPlace(campus); if (i < campus.size()) campus.showNearest(i); }
        else if (c == "7") {
            std::string n = ask("Place name: ");
            if (n.empty()) { std::cout << "A name is needed.\n"; continue; }
            std::string b = ask("Building or area: "), h = ask("How to get there: "), t = ask("Type (e.g. Hostel, Food, Other): ");
            campus.addCustomPlace(n, b, h, t);
            std::cout << "Added. It will appear in the list from now on.\n";
        }
        else if (c == "8") campus.showProgress();
        else std::cout << "Please choose a number from 0 to 8.\n";
    }
    std::cout << "Goodbye!\n";
}
